# Firmware Hub

A Samsung firmware finder with an IMEI format checker. No dependencies.

## Run it
1. Install Node.js 18 or newer.
2. In this folder run: `node server.js`
3. Open http://localhost:3000

## What is in it
- `server.js`: serves the site and two endpoints, `/api/firmware` and `/api/imei`. Firmware lookups are cached for one hour (not-found results for ten minutes), requests to Samsung time out after 8 seconds, and each IP is limited to 20 firmware lookups per minute.
- `public/`: the website (HTML, CSS, JavaScript).

## Deploy
Any Node host works (Render, Railway, Fly.io, a VPS). Set the start command to `node server.js`. The host provides PORT. Also set `TRUST_PROXY=1` when the host puts a proxy in front of the app, so rate limiting sees each visitor's real IP.

## Next steps
- Add more models to `public/models.js` (name and model number pairs).
- Add a page for each model.
- Add accounts or a donation link if you want to cover hosting.
