// Firmware Hub server. Node 18+, zero dependencies.
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, 'public');
const TRUST_PROXY = process.env.TRUST_PROXY === '1'; // set on hosts behind a proxy (Render, Railway, Fly.io)

const CACHE_MS = 60 * 60 * 1000;     // successful lookups: 1 hour
const MISS_CACHE_MS = 10 * 60 * 1000; // "not found" lookups: 10 minutes
const CACHE_MAX = 2000;               // max entries, oldest evicted first
const FETCH_TIMEOUT_MS = 8000;

const cache = new Map(); // key -> { t, ttl, data } (data is null for a cached miss)

function cacheSet(key, data, ttl) {
  cache.delete(key);
  cache.set(key, { t: Date.now(), ttl, data });
  while (cache.size > CACHE_MAX) cache.delete(cache.keys().next().value);
}

// ---- Rate limiting: fixed window per IP ----
const WINDOW_MS = 60 * 1000;
const LIMITS = { '/api/firmware': 20, '/api/imei': 60 }; // requests per minute per IP
const hits = new Map(); // `${ip}|${route}` -> { count, reset }

function clientIp(req) {
  if (TRUST_PROXY) {
    const xff = req.headers['x-forwarded-for'];
    if (xff) return xff.split(',')[0].trim();
  }
  return req.socket.remoteAddress || 'unknown';
}

// Returns seconds to wait if over the limit, otherwise 0.
function rateLimit(req, route) {
  const now = Date.now();
  const key = `${clientIp(req)}|${route}`;
  let h = hits.get(key);
  if (!h || now >= h.reset) { h = { count: 0, reset: now + WINDOW_MS }; hits.set(key, h); }
  h.count++;
  return h.count > LIMITS[route] ? Math.ceil((h.reset - now) / 1000) : 0;
}

setInterval(() => {
  const now = Date.now();
  for (const [k, h] of hits) if (now >= h.reset) hits.delete(k);
}, WINDOW_MS).unref();

// ---- Responses ----
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
};

function send(res, status, body, type = 'application/json; charset=utf-8', extra = {}) {
  res.writeHead(status, { 'Content-Type': type, ...extra });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}

// Samsung build strings end in year letter, month letter, build letter (e.g. ...BWLA).
function decodeBuild(pda) {
  const m = /([A-Z])([A-L])([0-9A-Z])$/.exec(pda);
  if (!m) return null;
  const year = 2001 + (m[1].charCodeAt(0) - 65);
  const month = m[2].charCodeAt(0) - 64;
  return { year, month };
}

async function getFirmware(model, csc) {
  const key = `${model}/${csc}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.t < hit.ttl) return hit.data;

  const url = `https://fota-cloud-dn.ospserver.net/firmware/${csc}/${model}/version.xml`;
  const r = await fetch(url, {
    headers: { 'User-Agent': 'Kies2.0' },
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
  });
  if (r.status === 403 || r.status === 404) { cacheSet(key, null, MISS_CACHE_MS); return null; }
  if (!r.ok) throw new Error(`Upstream returned ${r.status}`); // temporary problem: don't cache
  const xml = await r.text();

  const latest = /<latest[^>]*>([^<]+)<\/latest>/.exec(xml);
  if (!latest) { cacheSet(key, null, MISS_CACHE_MS); return null; }
  const [pda, cscBuild, modem] = latest[1].split('/');
  const history = [...xml.matchAll(/<upgrade[^>]*>([^<]+)<\/upgrade>/g)]
    .map(x => x[1].split('/')[0])
    .slice(-5)
    .reverse();

  const data = { model, csc, pda, cscBuild, modem: modem || null, released: decodeBuild(pda), history };
  cacheSet(key, data, CACHE_MS);
  return data;
}

function luhn(num) {
  let sum = 0;
  for (let i = 0; i < num.length; i++) {
    let d = Number(num[num.length - 1 - i]);
    if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return sum % 10 === 0;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

  if (url.pathname in LIMITS) {
    const wait = rateLimit(req, url.pathname);
    if (wait) {
      return send(res, 429, { error: `Too many requests. Try again in ${wait} seconds.` },
        undefined, { 'Retry-After': String(wait) });
    }
  }

  if (url.pathname === '/api/firmware') {
    const model = (url.searchParams.get('model') || '').trim().toUpperCase();
    const csc = (url.searchParams.get('csc') || '').trim().toUpperCase();
    if (!/^SM-[A-Z0-9]{3,8}$/.test(model)) return send(res, 400, { error: 'Enter a model like SM-S918B.' });
    if (!/^[A-Z]{3}$/.test(csc)) return send(res, 400, { error: 'Enter a 3-letter region code like XAA.' });
    try {
      const data = await getFirmware(model, csc);
      if (!data) return send(res, 404, { error: `No firmware found for ${model} in ${csc}. Check the model and region code.` });
      return send(res, 200, data);
    } catch {
      return send(res, 502, { error: 'Could not reach the firmware server. Try again in a minute.' });
    }
  }

  if (url.pathname === '/api/imei') {
    const imei = (url.searchParams.get('imei') || '').replace(/[\s-]/g, '');
    if (!/^\d{15}$/.test(imei)) return send(res, 400, { error: 'An IMEI has exactly 15 digits.' });
    return send(res, 200, { imei, tac: imei.slice(0, 8), validFormat: luhn(imei) });
  }

  // Static files
  let rel;
  try { rel = decodeURIComponent(url.pathname); } catch { return send(res, 400, 'Bad request', 'text/plain'); }
  if (rel === '/') rel = '/index.html';
  const full = path.normalize(path.join(PUBLIC, rel));
  if (!full.startsWith(PUBLIC + path.sep)) return send(res, 403, 'Forbidden', 'text/plain');
  fs.readFile(full, (err, buf) => {
    if (err) return send(res, 404, 'Not found', 'text/plain');
    const ext = path.extname(full);
    // HTML is always revalidated so deploys show up; CSS/JS are cached for an hour.
    const cc = ext === '.html' ? 'no-cache' : 'public, max-age=3600';
    send(res, 200, buf, MIME[ext] || 'application/octet-stream', { 'Cache-Control': cc });
  });
});

server.listen(PORT, () => console.log(`Firmware Hub running at http://localhost:${PORT}`));
