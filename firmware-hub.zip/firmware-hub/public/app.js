const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

function el(tag, props = {}, ...kids) {
  const node = document.createElement(tag);
  Object.assign(node, props);
  kids.forEach(k => node.append(k));
  return node;
}

function message(text, kind) {
  return el('p', { className: `msg ${kind}` }, text);
}

async function getJSON(url) {
  const r = await fetch(url);
  const data = await r.json();
  if (!r.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}

function renderBuild(d) {
  const dl = el('dl');
  const add = (k, v) => { dl.append(el('dt', {}, k), el('dd', {}, v)); };
  add('Build (PDA)', d.pda);
  add('CSC build', d.cscBuild);
  if (d.modem) add('Modem (CP)', d.modem);
  if (d.released) add('Released', `${MONTHS[d.released.month - 1]} ${d.released.year}`);
  const box = el('div', { className: 'build' }, el('h3', {}, `${d.model} in ${d.csc}`), dl);
  if (d.history.length) {
    box.append(el('p', { className: 'empty' }, 'Earlier builds'));
    const ul = el('ul');
    d.history.forEach(h => ul.append(el('li', {}, h)));
    box.append(ul);
  }
  return box;
}

const fwForm = document.getElementById('fw-form');
const fwResult = document.getElementById('fw-result');
fwForm.addEventListener('submit', async e => {
  e.preventDefault();
  const btn = fwForm.querySelector('button');
  btn.disabled = true;
  fwResult.replaceChildren(message('Looking up firmware…', 'ok'));
  try {
    const q = new URLSearchParams({ model: fwForm.model.value, csc: fwForm.csc.value });
    const data = await getJSON(`/api/firmware?${q}`);
    fwResult.replaceChildren(renderBuild(data));
  } catch (err) {
    fwResult.replaceChildren(message(err.message, 'err'));
  } finally {
    btn.disabled = false;
  }
});

const imeiForm = document.getElementById('imei-form');
const imeiResult = document.getElementById('imei-result');
imeiForm.addEventListener('submit', async e => {
  e.preventDefault();
  try {
    const q = new URLSearchParams({ imei: document.getElementById('imei-input').value });
    const d = await getJSON(`/api/imei?${q}`);
    imeiResult.replaceChildren(d.validFormat
      ? message(`${d.imei} is correctly formed. Model code (TAC): ${d.tac}.`, 'ok')
      : message(`${d.imei} fails the check digit test. Re-check each digit.`, 'err'));
  } catch (err) {
    imeiResult.replaceChildren(message(err.message, 'err'));
  }
});

// Search by phone name: fills in the model number.
const nameSearch = document.getElementById('name-search');
const nameHits = document.getElementById('name-hits');
nameSearch.addEventListener('input', () => {
  const q = nameSearch.value.trim().toLowerCase();
  nameHits.replaceChildren();
  if (!q) { nameHits.hidden = true; return; }
  const matches = MODELS.filter(([name, code]) =>
    name.toLowerCase().includes(q) || code.toLowerCase().includes(q)).slice(0, 8);
  if (!matches.length) {
    nameHits.append(el('li', {}, el('p', { className: 'empty', style: 'padding:.6rem .85rem' },
      'No match. Find your model number in Settings > About phone.')));
  }
  matches.forEach(([name, code]) => {
    const b = el('button', { type: 'button' }, name, el('code', {}, code));
    b.addEventListener('click', () => {
      fwForm.model.value = code;
      nameSearch.value = name;
      nameHits.hidden = true;
      fwForm.csc.focus();
    });
    nameHits.append(el('li', {}, b));
  });
  nameHits.hidden = false;
});
